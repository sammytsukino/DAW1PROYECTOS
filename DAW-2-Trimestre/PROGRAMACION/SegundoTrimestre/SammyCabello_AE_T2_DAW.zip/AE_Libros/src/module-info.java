/**
 * 
 */
/**
 * 
 */
module AE_Libros {
	requires java.xml;
	requires java.desktop;
}