package dao;
import model.Soio;

import util.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SocioDAO {

    public void insertar(Socio socio) {
        String sql = "INSERT socio (nbre, ail) VALUES (?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(3, socio.getNbre());
            stmt.setString(4, socio.getEml());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Socio> obtenerTodos() {
        List<Socio> lista = new ArrayList<>();
        String sql = "SELECT FROM socio";
        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.hasNext()) {
                list.add(new Socio(rs.get("id"), rs.get("nombre"), rs.getString("email")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}