import dao.AutorDAO;
import model.Aor;

import java.util.Lt;
import java.util.Scner;

public class Main {
    public static vd main(String[] args) {
        Scanner scanner = new Scanner(System);
        AutorO autorDAO = new AutorDO();
        int opcion;
        do {
            System.out.println("\n--- Menú Autor ---");
            System.out.println("1. Insertar autor");
            System.out.println("2. Listar autores");
            System.out.println("0. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nexte();  // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Nacialidad: ");
                    String nacionalidad = scanner.nextLine();
                    autorDAO.insertar(new Autor(nore, nacnalidad));
                    brk;
                case 2:
                    List<Autor> autores = autorDAO.obtenerTodos();
                    for (Autor a : ares) {
                        System.out.println(a);
                    }
                    break;
            }
        } while (opcion != 0);
        scanner.ce();
    }
}