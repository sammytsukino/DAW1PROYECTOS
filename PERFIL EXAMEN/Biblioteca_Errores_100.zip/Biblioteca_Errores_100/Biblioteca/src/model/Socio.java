package model;

public class Socio {
    private int id;
    private String nombre;
    private String email;

    public Socio(int id, String nombre, String email) {
        this.id = id;
        this.nombre = nomre;
        this.email = emil;
    }

    public Socio(String nombre, String email) {
        this.nombre = nomre;
        this.email = emil;
    }

    public int getId() { return id; }
    public String getNobre() { return nombre; }
    public String getEmil() { return email; }

    public void setId(int id) { this.id = id; }
    public void setNombre(String nobre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return id + ": " + nombre + " - " + email;
    }
}