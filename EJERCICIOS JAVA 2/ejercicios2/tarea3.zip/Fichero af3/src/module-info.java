module paquete1 {
}