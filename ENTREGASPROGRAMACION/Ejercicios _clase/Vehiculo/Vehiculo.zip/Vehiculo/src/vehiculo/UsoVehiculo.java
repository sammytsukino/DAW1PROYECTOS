package vehiculo;

public enum UsoVehiculo {
    MILITAR, 
    CIVIL
}