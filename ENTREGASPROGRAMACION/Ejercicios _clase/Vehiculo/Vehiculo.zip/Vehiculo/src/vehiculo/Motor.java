package vehiculo;

public interface Motor {
    int calcularRevolucionesMotor(int fuerza, int radio);
}