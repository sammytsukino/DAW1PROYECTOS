package vehiculo;

public enum TipoVehiculoAcuatico {
    SUPERFICIE, 
    SUBMARINO
}