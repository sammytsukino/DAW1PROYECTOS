package vehiculo;

public interface Vela {
    void recomendarVelocidad(int velocidadViento);
}