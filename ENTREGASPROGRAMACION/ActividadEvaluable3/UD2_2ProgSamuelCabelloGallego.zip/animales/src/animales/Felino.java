package animales;

public abstract class Felino extends Animal {
    public Felino(String habitat, String comida, String sonido, String nombreCientifico) {
        super(habitat, comida, sonido, nombreCientifico);
    }
}