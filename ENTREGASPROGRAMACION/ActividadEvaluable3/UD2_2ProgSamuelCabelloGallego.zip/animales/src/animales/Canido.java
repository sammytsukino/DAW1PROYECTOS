package animales;

public abstract class Canido extends Animal {
    public Canido(String habitat, String comida, String sonido, String nombreCientifico) {
        super(habitat, comida, sonido, nombreCientifico);
    }
}